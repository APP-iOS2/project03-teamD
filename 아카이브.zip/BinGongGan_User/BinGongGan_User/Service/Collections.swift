//
//  Collections.swift
//  BinGongGan_User
//
//  Created by 마경미 on 11.09.23.
//

import Foundation

enum Collections: String {
    case users = "users"
    case reviews = "reviews"
}
