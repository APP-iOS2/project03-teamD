//
//  ApprovedPlaceListView.swift
//  BinGongGan_Seller
//
//  Created by 오영석 on 2023/09/11.
//

import SwiftUI

struct ApprovedPlaceListView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ApprovedPlaceListView_Previews: PreviewProvider {
    static var previews: some View {
        ApprovedPlaceListView()
    }
}
