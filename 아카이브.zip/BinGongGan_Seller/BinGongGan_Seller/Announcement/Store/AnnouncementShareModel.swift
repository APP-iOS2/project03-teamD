//
//  AnnouncementShareModel.swift
//  BinGongGan_Seller
//
//  Created by 오영석 on 2023/09/11.
//

import Foundation

struct ShareText: Identifiable {
    let id = UUID()
    let text: String
}
