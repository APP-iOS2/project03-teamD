//
//  HomeView.swift
//  BinGongGan_Seller
//
//  Created by 오영석 on 2023/09/05.
//

import SwiftUI
import BinGongGanCore

struct HomeView: View {
    @State private var isPresentedModal: Bool = false
    
    var body: some View {
        ZStack {
            Color.myBackground
                .ignoresSafeArea(.all)
            NavigationStack {
                ScrollView {
                    HStack{
                        Text("전체 메뉴")
                            .font(.title2)
                            .bold()
                            .padding([.top, .leading], 20)
                            .foregroundColor(Color.black)
                        Spacer()
                    }
                    CategoryButtonsView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 10)
                    HStack{
                        Text("신규 예약")
                            .font(.title2)
                            .bold()
                            .padding(.leading, 20)
                            .foregroundColor(Color.black)
                        Spacer()
                    }
                    ForEach(0..<5) { _ in
                        ReservationCell()
                            .padding(.bottom, 12)
                            .padding(.horizontal, 20)
                            .overlay(
                                VStack {
                                    Button(action: {
                                        isPresentedModal.toggle()
                                    }) {
                                        Image(systemName: "chevron.right")
                                            .background(Color.clear)
                                            .foregroundColor(Color.myBrown)
                                    }
                                    .buttonStyle(.plain)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                                    .padding(EdgeInsets(top: 20, leading: 0, bottom: 0, trailing: 40))
                                    Spacer()
                                }
                                    .sheet(isPresented: self.$isPresentedModal) {
                                        ReservationDetailSheet()
                                            .presentationDetents([.medium])
                                            .cornerRadius(15)
                                    }
                            )
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        HStack{
                            Image("HomeLogo")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                            Text("BinGongGan")
                                .bold()
                                .foregroundColor(Color.myBrown)
                        }
                        .padding(EdgeInsets(top: 10, leading: 10, bottom: 15, trailing: 0))
                    }
                }
                .background(Color.myBackground)
            }
        }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
