//
//  RervationDetailsStore.swift
//  BinGongGan_Seller
//
//  Created by 김민기 on 2023/09/06.
//

import Foundation


class RervationDetailsStore :ObservableObject{
    
}
