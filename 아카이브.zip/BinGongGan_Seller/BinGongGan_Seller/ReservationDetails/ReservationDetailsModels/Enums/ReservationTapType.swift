//
//  ReservationTapType.swift
//  BinGongGan_Seller
//
//  Created by 김민기 on 2023/09/06.
//

import Foundation

enum ReservationTapType : String, CaseIterable {
    case list = "리스트"
    case calendar = "달력"
}
